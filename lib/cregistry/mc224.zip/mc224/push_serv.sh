#!/bin/bash

git add app.js request.js start.js package.json
git commit -m "stuff"
git push
