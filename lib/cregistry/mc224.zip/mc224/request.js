
var https = require('https');
var os = require('os');
var default_port = 443;

function create_msg(id, type, port, gps_coordinates){
  return {
    "id":id,
    "type":type,
    "gps":gps_coordinates,
    "port":port
  };
}

function register(device){
  var options = {
  host: 'mc224-jamscript.rhcloud.com',
  path: '/registration',
  port: default_port,
  //since we are listening on a custom port, we need to specify it by hand
  //port: '80',
  //This is what changes the request to a POST request
  method: 'POST',
  };
  var request = https.request(options, function(res) {
  console.log(res.statusCode);
  res.on('data', function(d) {
    var result = String(d);
    console.log(result);
    if(result.indexOf("Success:") == 0){
      device.id = result.slice("Success:".length, result.length);
    }else if(result.indexOf("IP_list:") == 0){
      device.parent_address = JSON.parse(result.slice("Success:".length, result.length));
    }
  });
  })
  request.write( JSON.stringify(device) , "Content-Type: application/json")
  request.end();

  request.on('error', function(e) {
  console.error(e);
  });
}

function heart_beat(device){
  var options = {
  host: 'mc224-jamscript.rhcloud.com',
  path: '/heart_beat',
  port: default_port,
  //since we are listening on a custom port, we need to specify it by hand
  //port: '80',
  //This is what changes the request to a POST request
  method: 'POST',
  };
  var request = https.request(options, function(res) {
  console.log(res.statusCode);
  res.on('data', function(d) {
    var result = String(d);
    console.log(result);
    if(result.indexOf("Success:") == 0){
      device.id = result.slice("Success:".length, result.length);
    }
  });
  })
  request.write( JSON.stringify(device) , "Content-Type: application/json")
  request.end();

  request.on('error', function(e) {
  console.error(e);
  });
  setTimeout(function(){heart_beat(device);}, 10000);
}

function update_ip_address(device){
  var interfaces = os.networkInterfaces();
  var addresses = {};
  for (var k in interfaces) {
    for (var k2 in interfaces[k]) {
      var address = interfaces[k][k2];
      if (address.family === 'IPv4' && !address.internal) {
        addresses.ipv4 = address.address;
      }else if(address.family === 'IPv6' && !address.internal){
        addresses.ipv6 = address.address;
      }
    }
  }
  device.address = addresses;
  setTimeout(function(){
      update_ip_address(device)}, 3600000);
}

function get_ip_address(device){
  var options = {
  host: 'mc224-jamscript.rhcloud.com',
  path: '/get_ip',
  port: default_port,
  //since we are listening on a custom port, we need to specify it by hand
  //port: '80',
  //This is what changes the request to a POST request
  method: 'POST',
  };

  var request = https.request(options, function(res) {
  console.log(res.statusCode);
  res.on('data', function(d) {
    var result = String(d);
    console.log(result);
    if(result.indexOf("Success:") == 0){
      device.id = result.slice("Success:".length, result.length);
    }else if(result.indexOf("IP_list:") == 0){
      device.parent_address = JSON.parse(result.slice("Success:".length, result.length));
      console.log(JSON.stringify(device));
    }
  });
  })
  request.write( JSON.stringify(device) , "Content-Type: application/json")
  request.end();

  request.on('error', function(e) {
  console.error(e);
  });
}

var device = create_msg("jam_test_app_8222739/fog_node", "fog_node" ,default_port,undefined);
update_ip_address(device);
console.log(device)
register(device);
setTimeout(function(){heart_beat(device);}, 10000);

//god dammit it