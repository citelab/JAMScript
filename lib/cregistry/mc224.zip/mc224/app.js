//db.device_list.runCommand( {"collMod" : "device_list" , "index" : { "keyPattern" : {} , "expireAfterSeconds" : 60 } } )
//To change the timeout ...

const http         = require('http'),
      fs           = require('fs'),
      path         = require('path'),
      contentTypes = require('./utils/content-types'),
      sysInfo      = require('./utils/sys-info'),
      env          = process.env;

var expiration_time = 120;

var mongojs = require('mongojs');
var new_device;

// if OPENSHIFT env variables are present, use the available connection info:
if(process.env.OPENSHIFT_MONGODB_DB_PASSWORD){
  connection_string = process.env.OPENSHIFT_MONGODB_DB_USERNAME + ":" +
  process.env.OPENSHIFT_MONGODB_DB_PASSWORD + "@" +
  process.env.OPENSHIFT_MONGODB_DB_HOST + ':' +
  process.env.OPENSHIFT_MONGODB_DB_PORT + '/' +
  process.env.OPENSHIFT_APP_NAME;
}
var connection_string = process.env.OPENSHIFT_MONGODB_DB_URL + process.env.OPENSHIFT_APP_NAME
var db = mongojs(connection_string, ['device_list']);
var device_list = db.collection('device_list');

db.device_list.createIndex( { "createdAt": 1 }, { expireAfterSeconds: expiration_time } )


function find_ip(res, ip_list, device_list, id, iteration){
  if(iteration == device_list.length - 1){
    res.write("IP_list:" + JSON.stringify(ip_list));
    //stuff
    return;
  }else{
    if(id == "")
      id = device_list[iteration];
    else
      id = id+"/"+device_list[iteration];
    db.device_list.find({"id":id}, function(err, doc) {
      if(doc.length == 0){
        res.write("Failure:cannot find node " + id);
        find_ip(res, ip_list, device_list, id, iteration +1);
        return;
      }else{
        res.write(JSON.stringify(doc));
        doc[0].address.id = id;
        doc[0].address.type = doc[0].type;
        ip_list.push(doc[0].address);
        find_ip(res, ip_list, device_list, id, iteration +1);
        return;
      }
    });
  }
}

function get_parent_ip_list(device, res){
  var ip_list = [];
  db.device_list.find({"id":device.id}, function(err, doc) {
      if(doc.length == 0){
        res.write("Failure:cannot find node " + id);
      }else{
          if(doc[0].address != undefined){
            if(doc[0].address.length > 0){
              ip_list = doc[0].address;
            }
          }
      }
      res.write("IP_list:" + JSON.stringify(ip_list));
  });

  //var device_list = device.id.split("/");
  //find_ip(res, ip_list, device_list, "", 0);
}

function get_parent_id(str){
  var device_list = str.split("/");
  if(device_list.length == 0 || device_list.length == 1)
    return undefined;
  var ret = device_list[0];
  for(var i = 1; i < device_list.length - 1; i++){
    ret += "/"+device_list[i];
  }
  return ret;
}

function register_device(device, res){
    //var add_on = Math.ceil(Math.random() * 10000000);
    //var new_name = device.id + "_" + add_on;
    //db.device_list.find({id:device.id+"_" +add_on}, function(err, doc) {
    res.write("Registering ...");
    new_device = device;
    db.device_list.find({id:device.id}, function(err, doc) {
      res.write("Device callback ...");
      if(doc.length == 0){
        //so this name is free for us :D
        if(get_parent_id(new_device.id) == undefined){
          insert_device(new_device, res);
          res.end("Success:"+new_device.id);
          return;
        }
        db.device_list.find({id:get_parent_id(new_device.id)}, function(err, doc) {
        if(doc.length == 0){
            res.write("Failure:Cannot find parent");
          }else{
          if(doc[0].address == undefined){
            res.end("Uh weird errors ...");
            return;
          }
          if(doc[0].address.length > 0){
              new_device.parent_address = doc[0].address;
              if(doc[0].parent_address.length > 0)
                Array.prototype.push.apply(new_device.parent_address, doc[0].parent_address);
              res.write("IP_list:" + JSON.stringify(new_device.parent_address));
          }
        }
        insert_device(new_device, res);
        res.end("Success:"+new_device.id);
        });
      }else{
        res.write("Failure:Try another name");
        res.end("Connection END");
        //register_device(device, res);
      }
    });
}

function insert_device(device, res){ 
    device.createdAt = new Date();
    db.device_list.insert(device);
}

function process_heart_beat(res, old_device){
    db.device_list.find({id:old_device.id}, function(err, doc) {
      if(doc.length > 0){
        //insert_device(old_device, res);
        db.device_list.update({id: old_device.id}, {$set: {createdAt: new Date(), parent_address: old_device.parent_address}}, {multi: true}, function () {
        // the update is complete
        //Here we need to find its parents ....
        res.end("Success:"+old_device.id);  
        })
      }else{
        register_device(old_device, res);
      }
    });
}

let server = http.createServer(function (req, res) {

  let url = req.url;
  if (url == '/') {
    url += 'index.html';
  }

  // IMPORTANT: Your application HAS to respond to GET /health with status 200
  //            for OpenShift health monitoring
  if (url == '/health') {
    res.writeHead(200);
    res.end();
  } else if (url == '/info/gen' || url == '/info/poll') {
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Cache-Control', 'no-cache, no-store');
    res.end(JSON.stringify(sysInfo[url.slice(6)]()));
  } else if(url.indexOf('/registration') == 0){
    req.on('data', function(chunk) {
      var new_device = JSON.parse(chunk.toString());
      register_device(new_device, res);
    });
  } else if(url.indexOf('/heart_beat') == 0){
    req.on('data', function(chunk) {
      var old_device = JSON.parse(chunk.toString());
      process_heart_beat(res, old_device);
    });
  } else if(url.indexOf('/get_ip') == 0){
    req.on('data', function(chunk) {
      var new_device = JSON.parse(chunk.toString());
      get_parent_ip_list(new_device, res);
      res.end("Success:"+new_device.id);
    });
  }
    else {
    fs.readFile('./static' + url, function (err, data) {
      if (err) {
        res.writeHead(404);
        res.end('Not found');
      } else {
        let ext = path.extname(url).slice(1);
        res.setHeader('Content-Type', contentTypes[ext]);
        if (ext === 'html') {
          res.setHeader('Cache-Control', 'no-cache, no-store');
        }
        res.end(data);
      }
    });
  }
});

server.listen(env.NODE_PORT || 3000, env.NODE_IP || 'localhost', function () {
  console.log(`Application worker ${process.pid} started...`);
});
